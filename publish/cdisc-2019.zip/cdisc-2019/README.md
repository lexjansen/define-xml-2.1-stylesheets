# Introduction

Define-XML v2.1 was published on May 15, 2019.

This zip file contains the examples and stylesheet related to Define.XML v2.1.

## Table of contents

- stylesheet folder -- XSL Stylesheet following the Define-XML Stylesheet Recommnedations developed through the PhUSE Optimizing the Use of Data Standards working Group.
- examples folder -- Sample ADaM And SDTM Deinfe-XML v2.1 documents
