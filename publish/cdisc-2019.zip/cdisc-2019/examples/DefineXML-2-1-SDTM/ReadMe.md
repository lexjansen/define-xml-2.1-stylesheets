### Define-XML-2-1-SDTM folder:  
 defineV21-SDTM.xml - define-XML V21 SDTM example.  Note that the .xpt dataset files and .pdf documents referenced in the XML code are not provided.  
 defineV21-SDTM.html - defineV2-SDTM xml document rendered using the XSL file named define2-1.xsl in the [stylesheets](../../stylesheets) folder.  
 ReadMe.md - this file.  