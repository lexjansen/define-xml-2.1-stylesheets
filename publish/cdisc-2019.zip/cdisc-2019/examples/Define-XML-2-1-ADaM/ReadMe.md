### adam folder:
 defineV21-ADaM.xml - Define-XML V.2 example for ADaM datasets and Analysis Results Metadata.  The dataset .xpt files referenced in the def:leaf elements are not provided.   
 defineV21-ADaM.html - defineV2-ADaM xml document rendered using the XSL stylesheet named define2-1.xsl in the [stylesheets](../../stylesheets) folder.  
 adrg.pdf - dummy Analysis Data Reviewer's Guide document.  

### dummy-csr folder:
 dummy-csr.pdf -- dummy clinical study report PDF file. Referenced in the Analysis Results Metadata.  

### programs folder:
 adae-sas.txt  - dummy SAS program file referenced in the ADAE dataset defintion.  
 adqsadas-sas.txt - dummy SAS program file referenced in the ADQSADAS dataset definition.  
 adsl-sas.txt - dummy SAS program file referenced in the ADSL dataset definition.  
 at14-5-02-sas.txt - dummy SAS program file referenced in the Analysis Results Metadata.  